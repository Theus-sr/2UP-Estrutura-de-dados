#!/usr/bin/env python3
"""
main.py — Ponto de entrada do Workflow Engine
Executa os três cenários (básico, avançado, estresse) e salva relatórios.

Uso:
  python main.py
  python main.py --scenario estresse
  python main.py --no-generate      (reutiliza JSONs existentes)
"""

import argparse
import os
import sys
import time

# adiciona src ao path para que os módulos sejam encontrados
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from engine import WorkflowEngine
import generate_data as gen
import random


DATA_DIR    = os.path.join(os.path.dirname(__file__), "data")
REPORTS_DIR = os.path.join(os.path.dirname(__file__), "reports")

SCENARIOS = {
    "basico":    ("input_basico.json",    "report_basico.json"),
    "avancado":  ("input_avancado.json",  "report_avancado.json"),
    "estresse":  ("input_estresse.json",  "report_estresse.json"),
}


def run_scenario(name: str, input_path: str, report_path: str) -> None:
    os.makedirs(REPORTS_DIR, exist_ok=True)

    engine = WorkflowEngine()
    print(f"  ▶  Carregando {os.path.basename(input_path)} …")
    t0 = time.perf_counter()
    engine.load_from_json(input_path)
    load_ms = (time.perf_counter() - t0) * 1000
    print(f"     Grafo carregado em {load_ms:.1f} ms")

    report = engine.run(scenario=name)
    engine.print_report(report)
    engine.save_report(report, report_path)
    print(f"  📄 Relatório salvo em: {report_path}\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Workflow Engine — Orquestrador de Agentes")
    parser.add_argument(
        "--scenario",
        choices=list(SCENARIOS.keys()) + ["todos"],
        default="todos",
        help="Cenário a executar (padrão: todos)",
    )
    parser.add_argument(
        "--no-generate",
        action="store_true",
        help="Pula geração de dados e usa JSONs existentes",
    )
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    # ── Geração de dados ──────────────────────────────────────────
    if not args.no_generate:
        print("\n" + "═" * 60)
        print("  ETAPA 1 — Geração de Dados de Teste")
        print("═" * 60)
        rng = random.Random(args.seed)
        os.makedirs(DATA_DIR, exist_ok=True)

        def _write(data, fname):
            import json
            path = os.path.join(DATA_DIR, fname)
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(data, fh, separators=(",", ":"), ensure_ascii=False)
            size_kb = os.path.getsize(path) / 1024
            n_tasks = len(data["tasks"])
            n_deps  = len(data["dependencies"])
            print(f"  ✓  {fname:<30} {n_tasks:>7,} tarefas  "
                  f"{n_deps:>8,} deps  {size_kb:>8.1f} KB")

        t_gen = time.perf_counter()
        _write(gen.generate_basic(rng),    "input_basico.json")
        _write(gen.generate_advanced(rng), "input_avancado.json")
        _write(gen.generate_stress(rng),   "input_estresse.json")
        print(f"\n  Tempo geração: {(time.perf_counter()-t_gen)*1000:.0f} ms")

    # ── Execução ───────────────────────────────────────────────────
    print("\n" + "═" * 60)
    print("  ETAPA 2 — Execução do Workflow Engine")
    print("═" * 60 + "\n")

    targets = (
        SCENARIOS.keys()
        if args.scenario == "todos"
        else [args.scenario]
    )

    for name in targets:
        inp_file, rep_file = SCENARIOS[name]
        inp_path = os.path.join(DATA_DIR,    inp_file)
        rep_path = os.path.join(REPORTS_DIR, rep_file)

        if not os.path.exists(inp_path):
            print(f"  ⚠  {inp_path} não encontrado — pule ou rode sem --no-generate")
            continue

        print(f"{'─'*60}")
        print(f"  Cenário: {name.upper()}")
        print(f"{'─'*60}")
        run_scenario(name, inp_path, rep_path)

    print("Execução concluída.\n")


if __name__ == "__main__":
    main()
