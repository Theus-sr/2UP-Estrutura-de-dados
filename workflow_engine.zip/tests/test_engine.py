#!/usr/bin/env python3
"""
Testes unitários — Workflow Engine
Cobre RF01, RF02, RF03, RF04 com casos de borda.
Execute: python tests/test_engine.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from graph import DirectedGraph, Task
from heap import MaxHeap
from algorithms import CycleDetector, TopologicalSorter


# ── helpers ───────────────────────────────────────────────────────

def make_task(tid: str, urgency: int = 50) -> Task:
    return Task(task_id=tid, name=f"task-{tid}", urgency=urgency)


def small_dag() -> DirectedGraph:
    """T0 → T1 → T3; T0 → T2 → T3; T3 → T4"""
    g = DirectedGraph()
    for i in range(5):
        g.add_task(make_task(f"T{i}", urgency=(5-i)*15))
    g.add_dependency("T0", "T1")
    g.add_dependency("T0", "T2")
    g.add_dependency("T1", "T3")
    g.add_dependency("T2", "T3")
    g.add_dependency("T3", "T4")
    return g


def cyclic_dag() -> DirectedGraph:
    """T0 → T1 → T2 → T3 → T1  (ciclo T1→T2→T3→T1)"""
    g = DirectedGraph()
    for i in range(4):
        g.add_task(make_task(f"T{i}"))
    g.add_dependency("T0", "T1")
    g.add_dependency("T1", "T2")
    g.add_dependency("T2", "T3")
    g.add_dependency("T3", "T1")   # fecha ciclo
    return g


# ── RF01 ──────────────────────────────────────────────────────────

def test_graph_add_task():
    g = DirectedGraph()
    t = make_task("A")
    g.add_task(t)
    assert g.node_count() == 1
    assert g.get_task("A") is t

def test_graph_add_duplicate_task():
    g = DirectedGraph()
    g.add_task(make_task("A"))
    g.add_task(make_task("A"))   # duplicata ignorada
    assert g.node_count() == 1

def test_graph_add_dependency():
    g = DirectedGraph()
    g.add_task(make_task("A"))
    g.add_task(make_task("B"))
    g.add_dependency("A", "B")
    assert "B" in g.successors("A")
    assert "A" in g.predecessors("B")
    assert g.in_degree("B") == 1
    assert g.edge_count() == 1

def test_graph_duplicate_edge():
    g = DirectedGraph()
    g.add_task(make_task("A"))
    g.add_task(make_task("B"))
    g.add_dependency("A", "B")
    g.add_dependency("A", "B")   # duplicata ignorada
    assert g.edge_count() == 1

def test_graph_unknown_node_raises():
    g = DirectedGraph()
    g.add_task(make_task("A"))
    try:
        g.add_dependency("A", "GHOST")
        assert False, "deveria ter lançado KeyError"
    except KeyError:
        pass

def test_graph_in_degree_snapshot_does_not_mutate():
    g = small_dag()
    snap = g.in_degree_snapshot()
    snap["T1"] = 999
    assert g.in_degree("T1") != 999   # grafo não mutado


# ── RF03 ──────────────────────────────────────────────────────────

def test_dfs_no_cycle():
    g = small_dag()
    r = CycleDetector(g).detect()
    assert not r.has_cycle
    assert len(r.visited_order) == 5

def test_dfs_detects_cycle():
    g = cyclic_dag()
    r = CycleDetector(g).detect()
    assert r.has_cycle
    assert r.cycle_edge is not None

def test_dfs_single_node():
    g = DirectedGraph()
    g.add_task(make_task("X"))
    r = CycleDetector(g).detect()
    assert not r.has_cycle

def test_dfs_self_loop():
    g = DirectedGraph()
    g.add_task(make_task("A"))
    g.add_task(make_task("B"))
    g.add_dependency("A", "B")
    g.add_dependency("B", "A")   # ciclo A↔B
    r = CycleDetector(g).detect()
    assert r.has_cycle

def test_dfs_deep_cycle():
    """Cadeia longa com ciclo no final."""
    g = DirectedGraph()
    n = 500
    for i in range(n):
        g.add_task(make_task(f"N{i}"))
    for i in range(n - 1):
        g.add_dependency(f"N{i}", f"N{i+1}")
    g.add_dependency(f"N{n-1}", "N0")   # ciclo profundo
    r = CycleDetector(g).detect()
    assert r.has_cycle


# ── RF02 ──────────────────────────────────────────────────────────

def test_kahn_success():
    g = small_dag()
    r = TopologicalSorter(g).sort()
    assert r.success
    assert len(r.order) == 5
    # T0 deve preceder T1, T2; T3 deve preceder T4
    o = r.order
    assert o.index("T0") < o.index("T1")
    assert o.index("T0") < o.index("T2")
    assert o.index("T1") < o.index("T3")
    assert o.index("T3") < o.index("T4")

def test_kahn_detects_cycle():
    g = cyclic_dag()
    r = TopologicalSorter(g).sort()
    assert not r.success
    assert len(r.remaining) > 0

def test_kahn_single_node():
    g = DirectedGraph()
    g.add_task(make_task("X"))
    r = TopologicalSorter(g).sort()
    assert r.success
    assert r.order == ["X"]

def test_kahn_priority_ordering():
    """Nós de mesma camada devem sair em ordem decrescente de urgência."""
    g = DirectedGraph()
    g.add_task(make_task("ROOT", urgency=100))
    g.add_task(make_task("A", urgency=20))
    g.add_task(make_task("B", urgency=80))
    g.add_task(make_task("C", urgency=50))
    g.add_dependency("ROOT", "A")
    g.add_dependency("ROOT", "B")
    g.add_dependency("ROOT", "C")
    r = TopologicalSorter(g).sort(use_priority=True)
    assert r.success
    # ROOT primeiro; depois B(80) > C(50) > A(20)
    assert r.order[0] == "ROOT"
    assert r.order[1] == "B"
    assert r.order[2] == "C"
    assert r.order[3] == "A"

def test_kahn_linear_chain():
    """Cadeia linear: única ordem possível."""
    g = DirectedGraph()
    n = 100
    for i in range(n):
        g.add_task(make_task(f"L{i}"))
    for i in range(n - 1):
        g.add_dependency(f"L{i}", f"L{i+1}")
    r = TopologicalSorter(g).sort()
    assert r.success
    assert r.order == [f"L{i}" for i in range(n)]


# ── RF04 ──────────────────────────────────────────────────────────

def test_heap_push_pop_order():
    h = MaxHeap()
    h.push("A", "alpha", 30)
    h.push("B", "beta",  90)
    h.push("C", "gamma", 60)
    assert h.pop().task_id == "B"   # urgência 90
    assert h.pop().task_id == "C"   # urgência 60
    assert h.pop().task_id == "A"   # urgência 30

def test_heap_peek_does_not_remove():
    h = MaxHeap()
    h.push("X", "x", 77)
    top = h.peek()
    assert top.task_id == "X"
    assert len(h) == 1

def test_heap_build_floyd():
    entries = [("T0","t0",10),("T1","t1",90),("T2","t2",50),
               ("T3","t3",70),("T4","t4",30)]
    h = MaxHeap()
    h.build(entries)
    assert len(h) == 5
    assert h.peek().priority == 90

def test_heap_fifo_tiebreak():
    h = MaxHeap()
    h.push("first",  "f", 50)
    h.push("second", "s", 50)
    h.push("third",  "t", 50)
    assert h.pop().task_id == "first"   # FIFO para prioridades iguais
    assert h.pop().task_id == "second"
    assert h.pop().task_id == "third"

def test_heap_empty_raises():
    h = MaxHeap()
    try:
        h.pop()
        assert False, "deveria ter lançado IndexError"
    except IndexError:
        pass

def test_heap_large():
    import random
    rng = random.Random(0)
    h = MaxHeap()
    n = 5000
    for i in range(n):
        h.push(f"T{i}", f"task{i}", rng.randint(1, 100))
    prev = 101
    while h:
        e = h.pop()
        assert e.priority <= prev
        prev = e.priority
    assert len(h) == 0


# ── Runner ────────────────────────────────────────────────────────

def run_all() -> None:
    tests = [
        # RF01
        test_graph_add_task,
        test_graph_add_duplicate_task,
        test_graph_add_dependency,
        test_graph_duplicate_edge,
        test_graph_unknown_node_raises,
        test_graph_in_degree_snapshot_does_not_mutate,
        # RF03
        test_dfs_no_cycle,
        test_dfs_detects_cycle,
        test_dfs_single_node,
        test_dfs_self_loop,
        test_dfs_deep_cycle,
        # RF02
        test_kahn_success,
        test_kahn_detects_cycle,
        test_kahn_single_node,
        test_kahn_priority_ordering,
        test_kahn_linear_chain,
        # RF04
        test_heap_push_pop_order,
        test_heap_peek_does_not_remove,
        test_heap_build_floyd,
        test_heap_fifo_tiebreak,
        test_heap_empty_raises,
        test_heap_large,
    ]
    passed = failed = 0
    print("\n" + "═" * 55)
    print("  TESTES UNITÁRIOS — Workflow Engine")
    print("═" * 55)
    for fn in tests:
        try:
            fn()
            print(f"  ✓  {fn.__name__}")
            passed += 1
        except Exception as e:
            print(f"  ✗  {fn.__name__}  →  {e}")
            failed += 1
    print("─" * 55)
    print(f"  {passed}/{len(tests)} testes passaram  "
          f"({'OK' if failed == 0 else f'{failed} FALHAS'})")
    print("═" * 55 + "\n")
    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    run_all()
