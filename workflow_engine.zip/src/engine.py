"""
Motor de Execução — Orquestrador de Agentes Autônomos

Integra RF01 (Grafo), RF02 (Kahn), RF03 (DFS), RF04 (MaxHeap)
em um pipeline coeso com relatório detalhado.
"""

from __future__ import annotations

import time
import json
from dataclasses import dataclass, field, asdict
from typing import Optional

from graph import DirectedGraph, Task
from heap import MaxHeap
from algorithms import CycleDetector, TopologicalSorter, CycleDetectionResult, TopologicalResult


@dataclass
class ExecutionReport:
    """Relatório completo de uma execução do workflow engine."""
    # Metadados
    scenario:          str
    graph_nodes:       int
    graph_edges:       int

    # RF03
    cycle_detection:   dict
    cycle_time_ms:     float

    # RF02
    topological_order: Optional[list[str]]
    topo_time_ms:      float
    topo_success:      bool

    # RF04
    heap_snapshot:     list[dict]   # top-20 tarefas prontas por urgência
    heap_size:         int

    # Totais
    total_time_ms:     float
    aborted:           bool
    abort_reason:      str = ""


class WorkflowEngine:
    """
    Motor principal que orquestra os 4 RFs:

    1. Carrega tarefas do JSON → constrói Grafo (RF01)
    2. Executa DFS → detecta ciclos/deadlocks (RF03) → aborta se necessário
    3. Executa Kahn → obtém sequência linear de execução (RF02)
    4. Alimenta MaxHeap com tarefas prontas (grau 0) → aloca por urgência (RF04)
    """

    def __init__(self) -> None:
        self.graph    = DirectedGraph()
        self.heap     = MaxHeap()
        self._loaded  = False

    # ── I/O ──────────────────────────────────────────────────────────

    def load_from_json(self, path: str) -> None:
        """
        Lê input JSON e popula o grafo.
        Formato esperado:
          {
            "tasks": [{"id": "...", "name": "...", "urgency": 80, "agent": "..."}],
            "dependencies": [{"from": "T1", "to": "T2"}]
          }
        """
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)

        # RF01 — adicionar nós
        for t in data["tasks"]:
            self.graph.add_task(Task(
                task_id=t["id"],
                name=t["name"],
                urgency=t.get("urgency", 50),
                agent=t.get("agent", ""),
                metadata=t.get("metadata", {}),
            ))

        # RF01 — adicionar arestas
        for dep in data["dependencies"]:
            self.graph.add_dependency(dep["from"], dep["to"])

        self._loaded = True

    # ── Pipeline de execução ─────────────────────────────────────────

    def run(self, scenario: str = "unnamed") -> ExecutionReport:
        """
        Executa o pipeline completo RF01→RF03→RF02→RF04.
        Retorna ExecutionReport com todos os dados relevantes.
        """
        t_start = time.perf_counter()

        # ── RF03: Detecção de ciclos (DFS) ───────────────────────────
        t0 = time.perf_counter()
        detector = CycleDetector(self.graph)
        cycle_result: CycleDetectionResult = detector.detect()
        cycle_ms = (time.perf_counter() - t0) * 1000

        if cycle_result.has_cycle:
            total_ms = (time.perf_counter() - t_start) * 1000
            return ExecutionReport(
                scenario=scenario,
                graph_nodes=self.graph.node_count(),
                graph_edges=self.graph.edge_count(),
                cycle_detection={
                    "has_cycle": True,
                    "cycle_edge": list(cycle_result.cycle_edge) if cycle_result.cycle_edge else [],
                    "cycle_path": cycle_result.cycle_path[:20],  # trunca para exibição
                },
                cycle_time_ms=round(cycle_ms, 3),
                topological_order=None,
                topo_time_ms=0.0,
                topo_success=False,
                heap_snapshot=[],
                heap_size=0,
                total_time_ms=round(total_ms, 3),
                aborted=True,
                abort_reason=(
                    f"DEADLOCK detectado: ciclo em "
                    f"{cycle_result.cycle_edge} — execução abortada (RF03)"
                ),
            )

        # ── RF02: Ordenação topológica (Kahn + MaxHeap) ──────────────
        t0 = time.perf_counter()
        sorter = TopologicalSorter(self.graph)
        topo_result: TopologicalResult = sorter.sort(use_priority=True)
        topo_ms = (time.perf_counter() - t0) * 1000

        # ── RF04: Alimenta MaxHeap com tarefas prontas ───────────────
        #  "tarefas prontas" = grau de entrada 0 no grafo original
        self.heap = MaxHeap()
        ready_tasks = [
            (t.task_id, t.name, t.urgency)
            for t in self.graph.all_tasks()
            if self.graph.in_degree(t.task_id) == 0
        ]
        self.heap.build(ready_tasks)   # O(N) Floyd heapify

        # snapshot top-20 por urgência
        snap = self.heap.snapshot()
        heap_snap = [
            {"task_id": e.task_id, "name": e.task_name, "urgency": e.priority}
            for e in snap[:20]
        ]

        total_ms = (time.perf_counter() - t_start) * 1000

        return ExecutionReport(
            scenario=scenario,
            graph_nodes=self.graph.node_count(),
            graph_edges=self.graph.edge_count(),
            cycle_detection={"has_cycle": False, "visited": len(cycle_result.visited_order)},
            cycle_time_ms=round(cycle_ms, 3),
            topological_order=topo_result.order,
            topo_time_ms=round(topo_ms, 3),
            topo_success=topo_result.success,
            heap_snapshot=heap_snap,
            heap_size=len(ready_tasks),
            total_time_ms=round(total_ms, 3),
            aborted=False,
        )

    def save_report(self, report: ExecutionReport, path: str) -> None:
        """Serializa o relatório em JSON."""
        out = asdict(report)
        # topo order pode ser muito grande — guarda apenas tamanho + amostra
        if out.get("topological_order") and len(out["topological_order"]) > 50:
            full = out["topological_order"]
            out["topological_order_sample"] = full[:25] + ["..."] + full[-25:]
            out["topological_order_total"]  = len(full)
            del out["topological_order"]
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(out, fh, indent=2, ensure_ascii=False)

    def print_report(self, report: ExecutionReport) -> None:
        """Exibe resumo legível no stdout."""
        sep = "─" * 60
        print(f"\n{'═'*60}")
        print(f"  WORKFLOW ENGINE — Cenário: {report.scenario.upper()}")
        print(f"{'═'*60}")
        print(f"  Grafo         : {report.graph_nodes:,} tarefas | {report.graph_edges:,} dependências")
        print(sep)

        # RF03
        cd = report.cycle_detection
        status = "⚠  CICLO DETECTADO" if cd["has_cycle"] else "✓  Sem ciclos"
        print(f"  RF03 DFS      : {status}  ({report.cycle_time_ms:.1f} ms)")
        if cd["has_cycle"]:
            print(f"  Aresta ciclo  : {cd['cycle_edge']}")
            print(f"  Caminho       : {' → '.join(cd['cycle_path'][:8])}...")
        print(sep)

        if report.aborted:
            print(f"  ⛔ EXECUÇÃO ABORTADA: {report.abort_reason}")
            print(f"{'═'*60}\n")
            return

        # RF02
        status2 = "✓  Sucesso" if report.topo_success else "✗  Falhou"
        print(f"  RF02 Kahn     : {status2}  ({report.topo_time_ms:.1f} ms)")
        if report.topological_order:
            sample = report.topological_order[:5]
            print(f"  Ordem (início): {' → '.join(sample)} ...")
        print(sep)

        # RF04
        print(f"  RF04 MaxHeap  : {report.heap_size} tarefas prontas")
        if report.heap_snapshot:
            top3 = report.heap_snapshot[:3]
            for e in top3:
                print(f"    [{e['urgency']:3d}] {e['name']}")
        print(sep)
        print(f"  Tempo total   : {report.total_time_ms:.1f} ms")
        print(f"{'═'*60}\n")
