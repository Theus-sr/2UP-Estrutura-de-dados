"""
RF01 — Grafo Direcionado com Lista de Adjacência
Modela dependências entre tarefas do workflow.
Complexidade:
  - Inserção de nó/aresta: O(1) amortizado
  - Acesso a vizinhos: O(1)
  - Espaço: O(V + E)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Iterator


@dataclass
class Task:
    """Nó do grafo: representa uma tarefa do workflow."""
    task_id: str
    name: str
    urgency: int          # prioridade para a Max-Heap (RF04)
    agent: str = ""
    metadata: dict = field(default_factory=dict)

    def __repr__(self) -> str:
        return f"Task({self.task_id!r}, urgency={self.urgency})"

    def __hash__(self) -> int:
        return hash(self.task_id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Task):
            return NotImplemented
        return self.task_id == other.task_id


class DirectedGraph:
    """
    Grafo Direcionado implementado com Lista de Adjacência.

    Representação interna:
      _nodes  : dict[str, Task]           — mapa id → Task
      _adj    : dict[str, list[str]]       — vizinhos de saída (u → [v, ...])
      _radj   : dict[str, list[str]]       — vizinhos de entrada (reverse adj)
      _in_deg : dict[str, int]             — grau de entrada (usado em Kahn)
    """

    def __init__(self) -> None:
        self._nodes:  dict[str, Task]       = {}
        self._adj:    dict[str, list[str]]  = {}   # u → successors
        self._radj:   dict[str, list[str]]  = {}   # v → predecessors
        self._in_deg: dict[str, int]        = {}

    # ── Inserção ────────────────────────────────────────────────────

    def add_task(self, task: Task) -> None:
        """Adiciona um nó (tarefa). O(1)."""
        tid = task.task_id
        if tid in self._nodes:
            return
        self._nodes[tid]  = task
        self._adj[tid]    = []
        self._radj[tid]   = []
        self._in_deg[tid] = 0

    def add_dependency(self, from_id: str, to_id: str) -> None:
        """
        Adiciona aresta direcionada from_id → to_id
        (to_id depende de from_id — from_id deve executar antes).
        O(1) amortizado.
        """
        if from_id not in self._nodes or to_id not in self._nodes:
            raise KeyError(f"Tarefa desconhecida: {from_id!r} ou {to_id!r}")
        # evita arestas duplicadas
        if to_id not in self._adj[from_id]:
            self._adj[from_id].append(to_id)
            self._radj[to_id].append(from_id)
            self._in_deg[to_id] += 1

    # ── Consultas ───────────────────────────────────────────────────

    def successors(self, task_id: str) -> list[str]:
        """Tarefas que dependem de task_id (filhos). O(1)."""
        return self._adj[task_id]

    def predecessors(self, task_id: str) -> list[str]:
        """Tarefas das quais task_id depende (pais). O(1)."""
        return self._radj[task_id]

    def in_degree(self, task_id: str) -> int:
        return self._in_deg[task_id]

    def get_task(self, task_id: str) -> Task:
        return self._nodes[task_id]

    def all_tasks(self) -> Iterator[Task]:
        return iter(self._nodes.values())

    def node_count(self) -> int:
        return len(self._nodes)

    def edge_count(self) -> int:
        return sum(len(v) for v in self._adj.values())

    # ── Snapshot para Kahn (copia graus sem alterar o grafo) ────────

    def in_degree_snapshot(self) -> dict[str, int]:
        """Cópia do vetor de graus de entrada. Usado por Kahn sem mutação."""
        return dict(self._in_deg)

    # ── Representação ───────────────────────────────────────────────

    def __repr__(self) -> str:
        return (f"DirectedGraph(V={self.node_count()}, "
                f"E={self.edge_count()})")
