"""
RF04 — Fila de Prioridade: Max-Heap baseada em urgência.

Complexidade:
  push  : O(log N)
  pop   : O(log N)
  peek  : O(1)
  build : O(N)  — heapify sobre lista inicial

Nenhuma biblioteca de heap é usada; implementação manual completa.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Generic, TypeVar

T = TypeVar("T")


@dataclass(order=False)
class HeapEntry:
    """Entrada na heap: (prioridade, id_de_inserção, dado)."""
    priority:    int
    insert_seq:  int   # desempate FIFO
    task_id:     str
    task_name:   str

    # Max-Heap: maior prioridade → topo
    def __lt__(self, other: "HeapEntry") -> bool:
        if self.priority != other.priority:
            return self.priority > other.priority      # invertido → max-heap
        return self.insert_seq < other.insert_seq      # FIFO para empates

    def __le__(self, other: "HeapEntry") -> bool:
        return self == other or self < other

    def __repr__(self) -> str:
        return f"[{self.priority}] {self.task_name}"


class MaxHeap:
    """
    Max-Heap manual para tarefas prontas (sem dependências pendentes).
    Internamente armazenada como array (lista Python).

    Índices (base 0):
      pai(i)      = (i - 1) // 2
      filho_esq(i) = 2*i + 1
      filho_dir(i) = 2*i + 2
    """

    def __init__(self) -> None:
        self._data: list[HeapEntry] = []
        self._seq: int = 0            # contador de inserção (desempate FIFO)

    # ── Operações principais ─────────────────────────────────────────

    def push(self, task_id: str, task_name: str, priority: int) -> None:
        """Insere tarefa na heap. O(log N)."""
        entry = HeapEntry(
            priority=priority,
            insert_seq=self._seq,
            task_id=task_id,
            task_name=task_name,
        )
        self._seq += 1
        self._data.append(entry)
        self._sift_up(len(self._data) - 1)

    def pop(self) -> HeapEntry:
        """Remove e retorna a tarefa de maior urgência. O(log N)."""
        if not self._data:
            raise IndexError("pop em heap vazia")
        self._swap(0, len(self._data) - 1)
        entry = self._data.pop()
        if self._data:
            self._sift_down(0)
        return entry

    def peek(self) -> HeapEntry:
        """Retorna o topo sem remover. O(1)."""
        if not self._data:
            raise IndexError("peek em heap vazia")
        return self._data[0]

    def build(self, entries: list[tuple[str, str, int]]) -> None:
        """
        Constrói a heap a partir de lista de (task_id, task_name, priority).
        Algoritmo Floyd: O(N) — mais eficiente que N pushes (N log N).
        """
        self._data = [
            HeapEntry(priority=p, insert_seq=i, task_id=tid, task_name=tn)
            for i, (tid, tn, p) in enumerate(entries)
        ]
        self._seq = len(self._data)
        # heapify de baixo para cima a partir do último pai
        last_parent = (len(self._data) - 2) // 2
        for i in range(last_parent, -1, -1):
            self._sift_down(i)

    def __len__(self) -> int:
        return len(self._data)

    def __bool__(self) -> bool:
        return bool(self._data)

    def __repr__(self) -> str:
        if not self._data:
            return "MaxHeap(vazia)"
        top = self._data[0]
        return f"MaxHeap(size={len(self)}, top={top})"

    # ── Operações internas ───────────────────────────────────────────

    def _swap(self, i: int, j: int) -> None:
        self._data[i], self._data[j] = self._data[j], self._data[i]

    def _sift_up(self, i: int) -> None:
        """Sobe o elemento i até restaurar a propriedade max-heap."""
        while i > 0:
            parent = (i - 1) // 2
            if self._data[i] < self._data[parent]:   # filho > pai (max-heap)
                self._swap(i, parent)
                i = parent
            else:
                break

    def _sift_down(self, i: int) -> None:
        """Desce o elemento i até restaurar a propriedade max-heap."""
        n = len(self._data)
        while True:
            largest = i
            left  = 2 * i + 1
            right = 2 * i + 2
            if left  < n and self._data[left]  < self._data[largest]:
                largest = left
            if right < n and self._data[right] < self._data[largest]:
                largest = right
            if largest == i:
                break
            self._swap(i, largest)
            i = largest

    def snapshot(self) -> list[HeapEntry]:
        """Retorna lista ordenada por prioridade (para debug/relatório). O(N log N)."""
        import copy
        tmp = MaxHeap()
        tmp._data = copy.deepcopy(self._data)
        result = []
        while tmp:
            result.append(tmp.pop())
        return result
