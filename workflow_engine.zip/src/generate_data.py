#!/usr/bin/env python3
"""
Gerador de Dados de Teste — Workflow Engine
Gera três cenários JSON sem hardcode:

  input_basico.json    — 20 tarefas,   30 dependências  (DAG limpo)
  input_avancado.json  — 200 tarefas,  500 dependências (estrutura multicamada)
  input_estresse.json  — 10.000 tarefas, 25.000 dependências + ciclo profundo oculto

Uso: python generate_data.py [--output-dir ./data]
"""

import argparse
import json
import random
import uuid
import os
import math
import time
from typing import Any

# ── Vocabulário sintético (sem biblioteca externa) ─────────────────

_AGENTS = [
    "auth-agent", "data-agent", "ml-agent", "cache-agent",
    "queue-agent", "api-agent", "db-agent", "monitor-agent",
    "transform-agent", "validate-agent", "notify-agent", "audit-agent",
]

_VERBS = [
    "fetch", "process", "validate", "transform", "cache",
    "persist", "notify", "aggregate", "compute", "index",
    "enrich", "filter", "route", "schedule", "deploy",
    "rollback", "checkpoint", "audit", "encrypt", "compress",
]

_NOUNS = [
    "payload", "record", "token", "session", "batch",
    "pipeline", "snapshot", "manifest", "config", "schema",
    "dataset", "index", "artifact", "transaction", "event",
    "metric", "log", "report", "queue", "partition",
]


def _task_name(rng: random.Random) -> str:
    return f"{rng.choice(_VERBS)}-{rng.choice(_NOUNS)}"


def _urgency(rng: random.Random) -> int:
    # distribuição enviesada: maioria entre 40–80, alguns críticos > 90
    r = rng.random()
    if r < 0.05:
        return rng.randint(91, 100)
    if r < 0.25:
        return rng.randint(75, 90)
    if r < 0.80:
        return rng.randint(40, 74)
    return rng.randint(1, 39)


# ── Gerador de DAG em camadas ──────────────────────────────────────

def _build_layered_dag(
    n_tasks: int,
    n_deps: int,
    rng: random.Random,
    cycle_depth: int = 0,          # 0 = sem ciclo
) -> dict[str, Any]:
    """
    Gera um DAG em camadas (layer-by-layer) garantindo acíclicidade,
    depois injeta um ciclo profundo se cycle_depth > 0.

    Estratégia:
      - Divide os nós em √N camadas de tamanho variável
      - Dependências só vão de camada i → camada j (j > i)
      - Garante ≥ 1 aresta por nó (exceto os raízes)
    """
    task_ids  = [f"T{i}" for i in range(n_tasks)]
    task_names = {tid: _task_name(rng) for tid in task_ids}
    urgencies  = {tid: _urgency(rng) for tid in task_ids}
    agents     = {tid: rng.choice(_AGENTS) for tid in task_ids}

    # divide em camadas
    n_layers = max(3, int(math.sqrt(n_tasks)))
    layers: list[list[str]] = []
    idx = 0
    for i in range(n_layers):
        # última camada pega o restante
        size = n_tasks // n_layers if i < n_layers - 1 else n_tasks - idx
        layers.append(task_ids[idx: idx + size])
        idx += size

    # garante pelo menos uma dependência de cada nó não-raiz
    dep_set: set[tuple[str, str]] = set()
    for layer_idx in range(1, len(layers)):
        for tid in layers[layer_idx]:
            src_layer = layers[layer_idx - 1]
            src = rng.choice(src_layer)
            dep_set.add((src, tid))

    # completa até n_deps com dependências aleatórias entre camadas
    attempts = 0
    while len(dep_set) < n_deps and attempts < n_deps * 10:
        attempts += 1
        li = rng.randint(0, n_layers - 2)
        lj = rng.randint(li + 1, n_layers - 1)
        src = rng.choice(layers[li])
        dst = rng.choice(layers[lj])
        if src != dst:
            dep_set.add((src, dst))

    deps = [{"from": s, "to": d} for s, d in dep_set]

    # ── Ciclo profundo oculto ──────────────────────────────────────
    # Injeta uma aresta "backward" entre dois nós distantes para criar
    # um ciclo que só é detectável por DFS completa.
    if cycle_depth > 0 and len(layers) >= 2:
        # escolhe dois nós em camadas distantes
        deep_layer_idx = min(cycle_depth, len(layers) - 1)
        node_in_deep   = rng.choice(layers[deep_layer_idx])
        # procura um predecessor do predecessor (ancestors distantes)
        ancestor_layer = max(0, deep_layer_idx - cycle_depth)
        ancestor       = rng.choice(layers[ancestor_layer])
        # a aresta de RETORNO fecha o ciclo: deep → ancestor
        # (que é antepassado → deep, então deep → ancestor cria ciclo)
        deps.append({"from": node_in_deep, "to": ancestor})

    tasks = [
        {
            "id":      tid,
            "name":    task_names[tid],
            "urgency": urgencies[tid],
            "agent":   agents[tid],
        }
        for tid in task_ids
    ]

    return {"tasks": tasks, "dependencies": deps}


# ── Cenários ───────────────────────────────────────────────────────

def generate_basic(rng: random.Random) -> dict:
    """20 tarefas, 30 dependências — DAG simples para validação."""
    return _build_layered_dag(n_tasks=20, n_deps=30, rng=rng)


def generate_advanced(rng: random.Random) -> dict:
    """200 tarefas, 500 dependências — multicamada sem ciclos."""
    return _build_layered_dag(n_tasks=200, n_deps=500, rng=rng)


def generate_stress(rng: random.Random) -> dict:
    """
    10.000 tarefas, 25.000 dependências.
    Inclui um ciclo profundo oculto para validação do RF03.
    Meta da rubrica: ≥ 10.000 tarefas e ≥ 25.000 dependências.
    """
    return _build_layered_dag(
        n_tasks=10_000,
        n_deps=25_000,
        rng=rng,
        cycle_depth=15,   # ciclo oculto a 15 camadas de profundidade
    )


# ── Utilitários de saída ───────────────────────────────────────────

def _write(data: dict, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, separators=(",", ":"), ensure_ascii=False)
    size_kb = os.path.getsize(path) / 1024
    n_tasks = len(data["tasks"])
    n_deps  = len(data["dependencies"])
    print(f"  ✓  {os.path.basename(path):<30} "
          f"{n_tasks:>7,} tarefas  {n_deps:>8,} deps  {size_kb:>8.1f} KB")


# ── Entry-point ────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="Gerador de dados — Workflow Engine")
    parser.add_argument("--output-dir", default="data", metavar="DIR")
    parser.add_argument("--seed", type=int, default=42, help="Semente aleatória")
    args = parser.parse_args()

    rng = random.Random(args.seed)

    print("\nGerando cenários de teste para o Workflow Engine…\n")
    t0 = time.perf_counter()

    _write(generate_basic(rng),    os.path.join(args.output_dir, "input_basico.json"))
    _write(generate_advanced(rng), os.path.join(args.output_dir, "input_avancado.json"))
    _write(generate_stress(rng),   os.path.join(args.output_dir, "input_estresse.json"))

    elapsed = (time.perf_counter() - t0) * 1000
    print(f"\n  Tempo de geração: {elapsed:.0f} ms")
    print(f"  Diretório de saída: {os.path.abspath(args.output_dir)}\n")


if __name__ == "__main__":
    main()
