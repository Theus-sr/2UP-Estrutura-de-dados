"""
RF02 — Ordenação Topológica (Algoritmo de Kahn)
RF03 — Detecção de Ciclos via DFS (3-coloração)

Complexidade de ambos: O(V + E)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

from graph import DirectedGraph


# ══════════════════════════════════════════════════════════════════
# RF03 — DFS com detecção de ciclos (3-coloração: BRANCO/CINZA/PRETO)
# ══════════════════════════════════════════════════════════════════

class _Color(Enum):
    WHITE = auto()   # não visitado
    GRAY  = auto()   # em visita (na pilha de recursão atual)
    BLACK = auto()   # totalmente processado


@dataclass
class CycleDetectionResult:
    has_cycle:   bool
    cycle_path:  list[str] = field(default_factory=list)  # nós do ciclo (se houver)
    cycle_edge:  Optional[tuple[str, str]] = None          # aresta que fecha o ciclo
    visited_order: list[str] = field(default_factory=list)

    def __repr__(self) -> str:
        if self.has_cycle:
            return f"CycleDetected(edge={self.cycle_edge}, path={self.cycle_path})"
        return f"NoCycle(visited={len(self.visited_order)} nós)"


class CycleDetector:
    """
    DFS iterativa (não recursiva) para evitar RecursionError em grafos
    com 10.000+ nós.

    Algoritmo:
      - Mantém pilha explícita de (nó, índice_do_filho_atual)
      - Cor CINZA = nó está na pilha atual → back-edge = ciclo
      - Cor PRETA = nó totalmente processado → pode ser ignorado
    """

    def __init__(self, graph: DirectedGraph) -> None:
        self._g = graph

    def detect(self) -> CycleDetectionResult:
        """
        Executa DFS em todos os nós não visitados.
        Retorna ao primeiro ciclo encontrado.
        O(V + E).
        """
        color: dict[str, _Color] = {
            t.task_id: _Color.WHITE for t in self._g.all_tasks()
        }
        parent: dict[str, Optional[str]] = {
            t.task_id: None for t in self._g.all_tasks()
        }
        visited_order: list[str] = []

        for start in list(self._g._nodes.keys()):
            if color[start] is not _Color.WHITE:
                continue

            # pilha: (node_id, iterator_over_successors)
            stack: list[tuple[str, int]] = [(start, 0)]
            color[start] = _Color.GRAY

            while stack:
                node, child_idx = stack[-1]
                succs = self._g.successors(node)

                if child_idx < len(succs):
                    stack[-1] = (node, child_idx + 1)
                    nxt = succs[child_idx]

                    if color[nxt] is _Color.GRAY:
                        # back-edge → ciclo encontrado!
                        cycle_path = self._reconstruct_cycle(
                            stack, node, nxt, parent
                        )
                        return CycleDetectionResult(
                            has_cycle=True,
                            cycle_path=cycle_path,
                            cycle_edge=(node, nxt),
                            visited_order=visited_order,
                        )
                    if color[nxt] is _Color.WHITE:
                        color[nxt] = _Color.GRAY
                        parent[nxt] = node
                        stack.append((nxt, 0))
                else:
                    # todos os filhos processados → pinta de PRETO
                    color[node] = _Color.BLACK
                    visited_order.append(node)
                    stack.pop()

        return CycleDetectionResult(
            has_cycle=False,
            visited_order=visited_order,
        )

    @staticmethod
    def _reconstruct_cycle(
        stack: list[tuple[str, int]],
        back_from: str,
        back_to: str,
        parent: dict[str, Optional[str]],
    ) -> list[str]:
        """Reconstrói o caminho do ciclo a partir da pilha atual."""
        path = [node for node, _ in stack]
        # encontra o índice de back_to no caminho
        try:
            idx = path.index(back_to)
            return path[idx:] + [back_from, back_to]
        except ValueError:
            return [back_from, back_to]


# ══════════════════════════════════════════════════════════════════
# RF02 — Ordenação Topológica (Kahn — BFS com graus de entrada)
# ══════════════════════════════════════════════════════════════════

@dataclass
class TopologicalResult:
    success:       bool
    order:         list[str]        # sequência linear de execução
    total_tasks:   int
    remaining:     list[str] = field(default_factory=list)  # nós num ciclo (se falhou)

    def __repr__(self) -> str:
        if self.success:
            return (f"TopologicalOrder(tasks={self.total_tasks}, "
                    f"first={self.order[:3]}...)")
        return f"TopologicalFailed(in_cycle={self.remaining})"


class TopologicalSorter:
    """
    Algoritmo de Kahn para ordenação topológica.

    Invariante: um nó só é emitido quando todos os seus predecessores
    já foram emitidos (grau de entrada chega a zero).

    Detecta ciclos como efeito colateral: se ao final sobram nós com
    grau > 0, eles pertencem a ciclos.

    Integração com RF04: nós com mesmo grau de entrada são enfileirados
    em ordem decrescente de urgência (via MaxHeap), garantindo que
    tarefas mais urgentes sejam alocadas primeiro.

    O(V + E) para o algoritmo de Kahn.
    O(V log V) total pela heap de prioridade.
    """

    def __init__(self, graph: DirectedGraph) -> None:
        self._g = graph

    def sort(self, use_priority: bool = True) -> TopologicalResult:
        """
        Executa Kahn com fila de prioridade (MaxHeap) ou FIFO simples.

        use_priority=True  → O(V log V + E)  — desempate por urgência
        use_priority=False → O(V + E)         — FIFO puro
        """
        from heap import MaxHeap  # importação local evita ciclo de módulo

        in_deg = self._g.in_degree_snapshot()   # cópia — não muta o grafo
        order: list[str] = []

        if use_priority:
            ready: MaxHeap | list = MaxHeap()
            # inicializa com todos os nós de grau 0
            for tid, deg in in_deg.items():
                if deg == 0:
                    task = self._g.get_task(tid)
                    ready.push(tid, task.name, task.urgency)

            while ready:
                entry = ready.pop()
                node = entry.task_id
                order.append(node)

                for succ in self._g.successors(node):
                    in_deg[succ] -= 1
                    if in_deg[succ] == 0:
                        t = self._g.get_task(succ)
                        ready.push(succ, t.name, t.urgency)
        else:
            # fila FIFO simples (deque manual via lista com ponteiro)
            head = 0
            queue: list[str] = [tid for tid, d in in_deg.items() if d == 0]

            while head < len(queue):
                node = queue[head]
                head += 1
                order.append(node)

                for succ in self._g.successors(node):
                    in_deg[succ] -= 1
                    if in_deg[succ] == 0:
                        queue.append(succ)

        remaining = [tid for tid, d in in_deg.items() if d > 0]
        success = (len(order) == self._g.node_count())

        return TopologicalResult(
            success=success,
            order=order,
            total_tasks=len(order),
            remaining=remaining,
        )
